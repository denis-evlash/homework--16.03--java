public class Main {
    public static void main(String[] args) {
      byte mybite = 1;
      short myshort = mybite;
      int myint = myshort;
      long mylong = myint;
      double mydouble = mylong;
        System.out.println(mybite);
        System.out.println(myshort);
        System.out.println(myint);
        System.out.println(mylong);
        System.out.println(mydouble);
        System.out.println("Проект 2 :" );
        long lo = 1000;
        byte a = (byte) lo;
        short b = a;
        int c = b;
        double d = b;
        System.out.println(lo);
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println("project 3 :");
        String text = "I study Basic Java!";
      System.out.println(text);
        text.charAt(0);
      System.out.println(text.charAt(0));
      System.out.println(text.length()-1);
      System.out.println(text.charAt(18));
      System.out.println(text.contains("Java"));
      System.out.println(text.replace("a", "o"));
      System.out.println(text.toUpperCase());
      System.out.println(text.toLowerCase());
      System.out.println(text.substring(14,18));
      System.out.println(text.substring(0,13));



    }
}